﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository_project.Institute
{
    internal class TeachersDB
    {
        public static List<Teachers> teacherslist=new List<Teachers>();

    }
}
